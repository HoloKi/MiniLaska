var searchData=
[
  ['libera_30',['libera',['../group__LiberaMemoria.html#ga2ced6cdd3f09aa1631f9c14461664d2d',1,'libera(tower_t **scacchiera):&#160;laska.c'],['../group__LiberaMemoria.html#ga2ced6cdd3f09aa1631f9c14461664d2d',1,'libera(tower_t **scacchiera):&#160;laska.c']]]
];
