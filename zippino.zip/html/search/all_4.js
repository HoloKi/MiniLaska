var searchData=
[
  ['obbligomangiare_16',['obbligomangiare',['../group__MangiaPedine.html#ga05cdb52671f313436a4d8523daacebba',1,'laska.c']]]
];
