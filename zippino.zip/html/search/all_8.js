var searchData=
[
  ['tower_21',['tower',['../structtower.html',1,'']]],
  ['turno_22',['turno',['../group__Movimento.html#ga9f5c27ad585198b2e8c0f191a0de7485',1,'turno(tower_t **scacchiera, int conta):&#160;laska.c'],['../group__Movimento.html#ga9f5c27ad585198b2e8c0f191a0de7485',1,'turno(tower_t **scacchiera, int conta):&#160;laska.c']]]
];
