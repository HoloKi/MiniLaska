var searchData=
[
  ['controlli_40',['Controlli',['../group__Controlli.html',1,'']]],
  ['creascacchiera_41',['CreaScacchiera',['../group__CreaScacchiera.html',1,'']]]
];
