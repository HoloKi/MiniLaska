var searchData=
[
  ['obbligomangiare_35',['obbligomangiare',['../group__MangiaPedine.html#ga05cdb52671f313436a4d8523daacebba',1,'laska.c']]]
];
