Gruppo numero 48
881997 Vo Duy Khiem
886622 Pagnan Pietro