var searchData=
[
  ['controllamangio_1',['controllamangio',['../group__MangiaPedine.html#gab771a0fd91d5b58f55bf92ef61e7bb83',1,'laska.c']]],
  ['controlli_2',['Controlli',['../group__Controlli.html',1,'']]],
  ['controllo_5fpedine_5fpresenti_3',['controllo_pedine_presenti',['../group__Controlli.html#ga7d2bfddfecb1e61434897c5c2d494e83',1,'laska.c']]],
  ['controllodestinazione_4',['controllodestinazione',['../group__Controlli.html#gad7719c611aad5c026c9292e225ee9743',1,'laska.c']]],
  ['controllogrado_5',['controllogrado',['../group__Controlli.html#ga69b4af7fe90b1218e1c92301e430a07e',1,'laska.c']]],
  ['controllopedina_6',['controllopedina',['../group__Controlli.html#ga692d3eeb8c4bd279ea8eecee895d8b15',1,'laska.c']]],
  ['creascacchiera_7',['CreaScacchiera',['../group__CreaScacchiera.html',1,'']]]
];
