var searchData=
[
  ['spostapedina_38',['spostapedina',['../group__MangiaPedine.html#gafe0e477a00ad566341caaa78d2f2184b',1,'laska.c']]]
];
