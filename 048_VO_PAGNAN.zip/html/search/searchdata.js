var indexSectionsWithContent =
{
  0: "aclmoprst",
  1: "t",
  2: "aclmoprst",
  3: "clmp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Modules"
};

