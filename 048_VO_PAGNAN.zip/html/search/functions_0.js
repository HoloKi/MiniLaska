var searchData=
[
  ['angolopedine_24',['angolopedine',['../group__MangiaPedine.html#gab216490cc4273357fc19c55f9768ff0e',1,'laska.c']]]
];
